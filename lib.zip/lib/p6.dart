import 'package:flutter/material.dart';


class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int selectedIndex =0 ;
  @override
  Widget build(BuildContext context) {
    Widget Pages (int pagenumber,colour){
      return Padding(
        padding: const EdgeInsets.all(8.0),
        child: Center(
          child: Container(
            color: colour,

            child: Center(child: Text('this page is $pagenumber',style: TextStyle(fontSize: 20,color: Colors.cyan),)),
          ),
        ),
      );
    }

    List<Widget> pages = [
      Pages(1, Colors.red),
      Pages(2, Colors.green),
      Pages(3, Colors.blue),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text("Navigation Drawer Example"),
      ),
      drawer: Drawer(
        child:  ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(

              child: Column(
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
                    child: Icon(Icons.person, size: 40, color: Colors.blue),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'User Name',
                    style: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                ],
              ),
            ),


            ListTile(
            title: Text('page 1'),
            onTap: (){
              setState(() {
                selectedIndex=1;
              });
            },
          ),
          ListTile(
            title: Text('page 2'),
            onTap: (){
              setState(() {
                selectedIndex=2;
              });
            },
          ),
        ]
          ,)
      ),
      body: pages[selectedIndex],
    );
  }
}