import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class p12 extends StatefulWidget {
  const p12({super.key});

  @override
  State<p12> createState() => _p12State();
}

class _p12State extends State<p12> {

  @override
  Widget build(BuildContext context) {
    const arr1=['hello','brother','how','are','you'];

    return  Scaffold(
        
    );
  }
}
