import 'package:demo/user_list.dart';
import 'package:flutter/material.dart';


class AddUserScreen extends StatefulWidget {
  const AddUserScreen({super.key});

  @override
  State<AddUserScreen> createState() => _AddUserScreenState();
}

class _AddUserScreenState extends State<AddUserScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String? _fullName;
  String? _email;
  String? _phone;
  String? _dateOfBirth; // Store date as String (dd-mm-yyyy)
  String? _city;
  int? _gender; // Store gender as 0, 1, or 2
  List<String> _hobbies = [];
  String? _password;
  String? _confirmPassword;

  // For City dropdown
  final List<String> _cities = ['Mumbai', 'Delhi', 'Bangalore', 'Chennai'];

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        _dateOfBirth = '${picked.day.toString().padLeft(2, '0')}-${picked.month.toString().padLeft(2, '0')}-${picked.year}';
      });
    }
  }

  String? _validateDateOfBirth(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please select your date of birth';
    }

    // Parse date and calculate age
    final dateParts = value.split('-');
    if (dateParts.length != 3) {
      return 'Enter a valid date in dd-mm-yyyy format';
    }

    final day = int.parse(dateParts[0]);
    final month = int.parse(dateParts[1]);
    final year = int.parse(dateParts[2]);

    final birthDate = DateTime(year, month, day);
    final now = DateTime.now();
    int age = now.year - birthDate.year;
    if (now.month < birthDate.month || (now.month == birthDate.month && now.day < birthDate.day)) {
      age--;
    }

    if (age < 18 || age > 80) {
      return 'Age must be between 18 and 80';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(kToolbarHeight),
        child: AppBar(
          title: Text(
            'Add User',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          elevation: 2,
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.blue.shade300, Colors.blue.shade600],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              // Full Name
              TextFormField(
                decoration: InputDecoration(labelText: 'Full Name'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your full name';
                  }
                  final regExp = RegExp(r"^[a-zA-Z\s\'-]{3,50}$");
                  if (!regExp.hasMatch(value)) {
                    return 'Enter a valid full name (3-50 characters, alphabets only)';
                  }
                  return null;
                },
                onSaved: (value) => _fullName = value,
              ),

              // Email
              TextFormField(
                decoration: InputDecoration(labelText: 'Email Address'),
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your email address';
                  }
                  final regExp = RegExp(r'^[a-zA-Z0-9._%+]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
                  if (!regExp.hasMatch(value)) {
                    return 'Enter a valid email address';
                  }
                  return null;
                },
                onSaved: (value) => _email = value,
              ),

              // Phone Number
              TextFormField(
                decoration: InputDecoration(labelText: 'Mobile Number'),
                keyboardType: TextInputType.phone,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your mobile number';
                  }
                  final regExp = RegExp(r'^\+?[0-9]{10,15}$');
                  if (!regExp.hasMatch(value)) {
                    return 'Enter a valid mobile number';
                  }
                  return null;
                },
                onSaved: (value) => _phone = value,
              ),

              // Date of Birth (with Calendar Picker)
              TextFormField(
                decoration: InputDecoration(labelText: 'Date of Birth'),
                controller: TextEditingController(text: _dateOfBirth),
                readOnly: true,
                onTap: () => _selectDate(context),
                validator: _validateDateOfBirth,
                onSaved: (value) => _dateOfBirth = value,
              ),

              // City (Dropdown)
              DropdownButtonFormField<String>(
                decoration: InputDecoration(labelText: 'City'),
                value: _city,
                items: _cities.map((city) {
                  return DropdownMenuItem<String>(value: city, child: Text(city));
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _city = value;
                  });
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please select a city';
                  }
                  return null;
                },
                onSaved: (value) => _city = value,
              ),

              // Gender (Radio buttons - store as 0, 1, 2)
              ListTile(
                title: Text('Gender'),
                subtitle: Row(
                  children: [
                    Radio<int>(
                      value: 0, // Male
                      groupValue: _gender,
                      onChanged: (value) {
                        setState(() {
                          _gender = value!;
                        });
                      },
                    ),
                    Text('Male'),
                    Radio<int>(
                      value: 1, // Female
                      groupValue: _gender,
                      onChanged: (value) {
                        setState(() {
                          _gender = value!;
                        });
                      },
                    ),
                    Text('Female'),
                    Radio<int>(
                      value: 2, // Other
                      groupValue: _gender,
                      onChanged: (value) {
                        setState(() {
                          _gender = value!;
                        });
                      },
                    ),
                    Text('Other'),
                  ],
                ),
              ),

              // Hobbies (Multi-select checkboxes)
              CheckboxListTile(
                title: Text('Reading'),
                value: _hobbies.contains('Reading'),
                onChanged: (bool? value) {
                  setState(() {
                    if (value!) {
                      _hobbies.add('Reading');
                    } else {
                      _hobbies.remove('Reading');
                    }
                  });
                },
              ),
              CheckboxListTile(
                title: Text('Money Making'),
                value: _hobbies.contains('Traveling'),
                onChanged: (bool? value) {
                  setState(() {
                    if (value!) {
                      _hobbies.add('Traveling');
                    } else {
                      _hobbies.remove('Traveling');
                    }
                  });
                },
              ),
              CheckboxListTile(
                title: Text('Cooking'),
                value: _hobbies.contains('Cooking'),
                onChanged: (bool? value) {
                  setState(() {
                    if (value!) {
                      _hobbies.add('Cooking');
                    } else {
                      _hobbies.remove('Cooking');
                    }
                  });
                },
              ),

              // Password
              TextFormField(
                decoration: InputDecoration(labelText: 'Password'),
                obscureText: true,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a password';
                  }
                  return null;
                },
                onSaved: (value) => _password = value,
              ),

              // Confirm Password
              TextFormField(
                decoration: InputDecoration(labelText: 'Confirm Password'),
                obscureText: true,
                validator: (value) {
                  if (value == null || value != _password) {
                    return 'Passwords do not match';
                  }
                  return null;
                },
                onSaved: (value) => _confirmPassword = value,
              ),

              // Submit Button
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                child: ElevatedButton(
                  onPressed: () {
                    _formKey.currentState!.save();
                    if (_formKey.currentState!.validate()) {
                      users.add({
                        'name': _fullName,
                        'email': _email,
                        'phone': _phone,
                        'dateOfBirth': _dateOfBirth,
                        'gender': _gender,
                        'hobbies': _hobbies,
                        'password': _password,
                        'isFavorite': false,
                      });

                    }
                  },
                  child: Text('Submit'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
