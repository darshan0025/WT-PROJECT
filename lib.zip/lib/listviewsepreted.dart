import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class p11 extends StatefulWidget {
  const p11({super.key});

  @override
  State<p11> createState() => _p11State();
}

class _p11State extends State<p11> {

  @override
  Widget build(BuildContext context) {
    const arr1=['hello','brother','how','are','you'];

    return  Scaffold(
      appBar: AppBar(
        title: Text('code'),
      ),
      body: ListView.separated(itemBuilder: (context,index) {
        return Row(
          children: [
            Column(
              children: [
                Text(arr1[index],
                  style: TextStyle(fontWeight: FontWeight.w100, fontSize: 100),),
                Text(arr1[index],
                  style: TextStyle(fontWeight: FontWeight.w100, fontSize: 50),),
                Container(
                  child: Text('hellobabby'),
                  decoration: BoxDecoration(
                    color: Colors.amberAccent,

                  ),
                )
              ],
            ),
            Text(arr1[index],
              style: TextStyle(fontWeight: FontWeight.w100, fontSize: 100),),
          ],
        );
      },
        itemCount: arr1.length,
        separatorBuilder: (context,index){
        return Divider(height: 50,thickness: 1,);
        }
      )

    );
  }
}
