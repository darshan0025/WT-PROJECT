
class User {
  String name;
  String email;
  User({required this.name, required this.email});
}
