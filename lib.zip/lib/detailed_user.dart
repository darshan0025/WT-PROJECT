import 'package:flutter/material.dart';

import 'user_list.dart';

class UserListScreen extends StatefulWidget {
  final bool isFavorite;

  const UserListScreen({super.key, this.isFavorite = false});

  @override
  State<UserListScreen> createState() => _UserListScreenState();
}

class _UserListScreenState extends State<UserListScreen> {
  String searchQuery = "";

  // Function to calculate age from date of birth
  int calculateAge(String dateOfBirth) {
    final dobParts = dateOfBirth.split('-'); // Split the string into day, month, year
    final day = int.parse(dobParts[0]);
    final month = int.parse(dobParts[1]);
    final year = int.parse(dobParts[2]);

    final dob = DateTime(year, month, day); // Create a DateTime object
    final today = DateTime.now();
    int age = today.year - dob.year;
    if (today.month < dob.month || (today.month == dob.month && today.day < dob.day)) {
      age--;
    }
    return age;
  }

  @override
  Widget build(BuildContext context) {
    // Filter users based on the search query
    final filteredUsers = users
        .where((user) {
      final matchesSearch = user['name'].toLowerCase().contains(searchQuery.toLowerCase());
      final matchesFavorite = widget.isFavorite ? user['isFavorite'] == true : true;
      return matchesSearch && matchesFavorite;
    })
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.isFavorite ? 'Favorite List' : 'User List',
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: widget.isFavorite
            ? Colors.pink.shade300 // For favorites, use pink shades
            : Colors.green.shade300, // For non-favorites, use green shades
        elevation: 2, // Add subtle elevation for separation
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: widget.isFavorite
                  ? [Colors.pink.shade300, Colors.pink.shade600] // Gradient for favorites
                  : [Colors.green.shade300, Colors.green.shade600], // Gradient for non-favorites
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Search bar to filter users
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: TextFormField(
                decoration: InputDecoration(
                  hintText: 'Search users...',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                ),
                onChanged: (value) {
                  setState(() {
                    searchQuery = value;
                  });
                },
              ),
            ),
            // User List
            Expanded(
              child: ListView.builder(
                itemCount: filteredUsers.length,
                itemBuilder: (context, index) {
                  final user = filteredUsers[index];
                  final age = calculateAge(user['dateOfBirth']);

                  return Card(
                    margin: const EdgeInsets.all(8.0),
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // Left side: Name, Age, Email, Phone
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(Icons.person, color: Colors.grey),
                                  SizedBox(width: 8),
                                  Text(
                                    user['name'],
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Row(
                                children: [
                                  Icon(Icons.calendar_today, color: Colors.grey),
                                  SizedBox(width: 8),
                                  Text('$age years'),
                                ],
                              ),
                              SizedBox(height: 8),
                              Row(
                                children: [
                                  Icon(Icons.email, color: Colors.grey),
                                  SizedBox(width: 8),
                                  Text(user['email']),
                                ],
                              ),
                              SizedBox(height: 8),
                              Row(
                                children: [
                                  Icon(Icons.phone, color: Colors.grey),
                                  SizedBox(width: 8),
                                  Text(user['phone'].toString()),
                                ],
                              ),
                            ],
                          ),
                          // Right side: Favorite, Edit, Delete buttons
                          Column(
                            children: [
                              IconButton(
                                icon: Icon(
                                  user['isFavorite'] ? Icons.favorite : Icons.favorite_border,
                                  color: user['isFavorite'] ? Colors.red : Colors.grey,
                                ),
                                onPressed: () {
                                  setState(() {
                                    user['isFavorite'] = !user['isFavorite'];
                                  });
                                },
                              ),
                              IconButton(
                                icon: Icon(Icons.edit, color: Colors.blue),
                                onPressed: () {
                                  // Add your edit logic here
                                },
                              ),
                              IconButton(
                                icon: Icon(Icons.delete, color: Colors.red),
                                onPressed: () {
                                  setState(() {
                                    users.removeAt(index);
                                  });
                                },
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
