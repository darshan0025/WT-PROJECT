import 'package:flutter/material.dart';

class p5 extends StatelessWidget {
  const p5({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Hello'),
      ),
      body:ElevatedButton(onPressed: (){
        
      }, child: Text('hello world'))
    );
  }
}
