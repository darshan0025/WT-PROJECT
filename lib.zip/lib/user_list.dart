List<Map<dynamic, dynamic>> users = [
  {
    'name': 'Aarav Patel',
    'email': 'aarav.patel@gmail.com',
    'phone': 9876543210,
    'dateOfBirth': '15-08-1990',
    'gender': 1,
    'hobbies': ['Reading', 'Traveling'],
    'password': 'Aarav@123',
    'isFavorite': false,
  },
  {
    'name': 'Ananya Sharma',
    'email': 'ananya.sharma@yahoo.com',
    'phone': 9123456789,
    'dateOfBirth': '25-12-1985',
    'gender': 0,
    'hobbies': ['Cooking', 'Dancing'],
    'password': 'Ananya@456',
    'isFavorite': true,
  },
  {
    'name': 'Rohan Kumar',
    'email': 'rohan.kumar@outlook.com',
    'phone': 9988776655,
    'dateOfBirth': '10-06-2000',
    'gender': 1,
    'hobbies': ['Photography', 'Gaming'],
    'password': 'Rohan#789',
    'isFavorite': false,
  },

];
